#include "rafaelia_gpu.h"
static void _wr(const char*s,int n){
  register int r0 __asm__("r0")=1;
  register const char*r1 __asm__("r1")=s;
  register int r2 __asm__("r2")=n;
  register int r7 __asm__("r7")=4;
  __asm__ volatile("svc #0":"+r"(r0):"r"(r1),"r"(r2),"r"(r7):"memory");}
static void _exit(int c){
  register int r0 __asm__("r0")=c;
  register int r7 __asm__("r7")=1;
  __asm__ volatile("svc #0":"+r"(r0):"r"(r7));__builtin_unreachable();}
static const char _H[]="0123456789ABCDEF";
static void _phex(uint32_t v,int d){
  char b[8];int i;for(i=d-1;i>=0;i--){b[i]=_H[v&0xFu];v>>=4;}_wr(b,d);}
static void _pdec(uint32_t v){
  char b[10];int i=0,j;
  if(!v){_wr("0",1);return;}
  while(v){b[i++]=(char)('0'+v%10);v/=10;}
  char r[10];for(j=0;j<i;j++)r[j]=b[i-1-j];_wr(r,i);}
static gctx_t G __attribute__((aligned(64)));
static const uint8_t _P[]="RAFAELIA_TORUS7D_ARM32_KERNEL";
void _start(void){
  g_init(&G);int b=g_detect(&G);
  if(b==G_CL)_wr("BACKEND=CL\n",11);
  else if(b==G_NEON)_wr("BACKEND=NEON\n",13);
  else _wr("BACKEND=NONE\n",13);
  uint32_t i;
  for(i=0;i<G_PERIOD;i++){
    g_step(&G,_P,(uint32_t)(sizeof(_P)-1u));
    _wr("CY=",3);_pdec(G.st.phase);
    _wr(" PHI=",5);_phex(G.st.phi,4);
    _wr(" CRC=",5);_phex(G.st.crc,8);_wr("\n",1);}
  g_neon_burst(&G.st,G_PERIOD);
  _wr("BURST_PHI=",10);_phex(G.st.phi,4);_wr("\n",1);
  g_close(&G);_exit(0);}
