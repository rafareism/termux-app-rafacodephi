#include "rafaelia_gpu.h"
#include <string.h>
void g_init(gctx_t *c){
  memset(c->mem,0,G_ARENA);memset(c->cl,0,sizeof(c->cl));
  c->bump=0;c->backend=G_NONE;c->glib=0;g_state_init(&c->st);}
int g_detect(gctx_t *c){
  if(g_cl_init(c)){c->backend=G_CL;return G_CL;}
#ifdef __ARM_NEON
  c->backend=G_NEON;return G_NEON;
#else
  return G_NONE;
#endif
}
int g_step(gctx_t *c,const uint8_t *in,uint32_t n){
  if(!c->backend)return 0;
  uint32_t ci=g_crc32(in,n)&G_MASK;
  uint32_t hi=g_entropy(in,n);
  uint32_t cy=c->st.phase;
  if(!g_state_ok(&c->st))g_state_init(&c->st);
  if(c->backend==G_CL){if(g_cl_run(c,ci,hi,cy))return 1;c->backend=G_NEON;}
  {uint32_t tmp[7],i;
   g_neon_step(tmp,c->st.s,cy);
   for(i=0;i<7u;i++)c->st.s[i]=tmp[i];
   c->st.coh=g_ema(c->st.coh,ci);c->st.ent=g_ema(c->st.ent,hi);
   c->st.phi=g_phi_q(c->st.ent,c->st.coh);
   c->st.phase=(cy+1u>=G_PERIOD)?0u:cy+1u;
   c->st.step++;g_state_seal(&c->st);}
  return 1;}
void g_close(gctx_t *c){
  if(c->backend==G_CL)g_cl_close(c);
  memset(c->cl,0,sizeof(c->cl));c->backend=G_NONE;}
