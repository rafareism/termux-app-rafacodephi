#pragma once
#include <stdint.h>
#include <stddef.h>
/* RAFAELIA-GPU ARM32 armeabi-v7a Moto E7 Power Helio G25 MT6762G */
#define G_SPIRAL 56755u
#define G_PHI    105965u
#define G_PI_K   205887u
#define G_SIN279 3146u
#define G_MASK   0xFFFFu
#define G_PERIOD 42u
#define G_DIM    7u
#define G_EMA_H  49152u
#define G_EMA_L  16384u
#define G_NONE   0u
#define G_NEON   1u
#define G_CL     2u
#define G_VK     3u
#define G_ARENA  65536u
typedef struct __attribute__((packed,aligned(4))){
  uint32_t s[7];
  uint32_t coh,ent,phi,phase,step,crc;
} gstate_t;
typedef struct {
  uint8_t  mem[G_ARENA];
  uint32_t bump,backend;
  void    *glib;
  void    *cl[3];
  gstate_t st;
} gctx_t;
void     g_init  (gctx_t *c);
int      g_detect(gctx_t *c);
int      g_step  (gctx_t *c,const uint8_t *in,uint32_t n);
void     g_close (gctx_t *c);
uint32_t g_crc32 (const void *p,uint32_t n);
uint32_t g_ema   (uint32_t old,uint32_t in);
uint32_t g_phi_q (uint32_t H,uint32_t C);
uint32_t g_entropy(const uint8_t *buf,uint32_t n);
int      g_state_ok(gstate_t *s);
void     g_state_seal(gstate_t *s);
void     g_state_init(gstate_t *s);
void g_neon_step (uint32_t *dst,const uint32_t *src,uint32_t cycle);
void g_neon_burst(gstate_t *st,uint32_t cycles);
int  g_cl_init (gctx_t *c);
int  g_cl_run  (gctx_t *c,uint32_t ci,uint32_t hi,uint32_t cy);
void g_cl_close(gctx_t *c);
