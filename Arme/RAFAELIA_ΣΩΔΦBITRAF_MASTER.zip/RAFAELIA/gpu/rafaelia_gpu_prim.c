#include "rafaelia_gpu.h"
#include <string.h>
static uint32_t _ct[256];
static uint8_t  _cr=0;
static void _crc_build(void){
  uint32_t i,v,j;
  for(i=0;i<256u;i++){v=i;for(j=0;j<8u;j++)v=(v&1u)?(v>>1)^0x82F63B78u:(v>>1);_ct[i]=v;}
  _cr=1;
}
uint32_t g_crc32(const void *p,uint32_t n){
  if(!_cr)_crc_build();
  const uint8_t *b=(const uint8_t*)p;
  uint32_t c=0xFFFFFFFFu;
  while(n--)c=(c>>8)^_ct[(c^*b++)&0xFFu];
  return ~c;
}
uint32_t g_ema(uint32_t o,uint32_t i){
  return(uint32_t)(((uint64_t)o*G_EMA_H+(uint64_t)i*G_EMA_L)>>16);
}
uint32_t g_phi_q(uint32_t H,uint32_t C){
  uint32_t inv=(H<G_MASK)?(G_MASK-H):0u;
  return(uint32_t)(((uint64_t)inv*C)>>16);
}
uint32_t g_entropy(const uint8_t *buf,uint32_t n){
  uint8_t seen[256];uint32_t i,uniq=0,lim=(n<4096u)?n:4096u;
  memset(seen,0,256);
  for(i=0;i<lim;i++)if(!seen[buf[i]]){seen[buf[i]]=1;uniq++;}
  return(uint32_t)((uint64_t)uniq*65535u/256u);
}
int g_state_ok(gstate_t *s){
  uint32_t sv=s->crc;s->crc=0;
  uint32_t c=g_crc32(s,(uint32_t)offsetof(gstate_t,crc));
  s->crc=sv;return(c==sv);
}
void g_state_seal(gstate_t *s){s->crc=0;s->crc=g_crc32(s,(uint32_t)offsetof(gstate_t,crc));}
void g_state_init(gstate_t *s){
  static const uint32_t seeds[7]={56755u,105965u,205887u,46341u,92682u,138564u,184245u};
  uint32_t i;
  for(i=0;i<7u;i++)s->s[i]=seeds[i]&G_MASK;
  s->coh=0x8000u;s->ent=0x8000u;s->phi=0u;s->phase=0u;s->step=0u;
  g_state_seal(s);
}
