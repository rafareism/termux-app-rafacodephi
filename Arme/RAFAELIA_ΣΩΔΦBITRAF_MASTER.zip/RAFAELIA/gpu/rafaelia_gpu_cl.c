/* rafaelia_gpu_cl.c - OpenCL via dlopen ARM32 zero malloc
 * HF-03 APLICADO: _SYM(f,sym) usa nome real do simbolo OpenCL */
#include "rafaelia_gpu.h"
#include <dlfcn.h>
#include <stddef.h>
typedef void *plat_t,*dev_t,*ctx_t,*q_t,*prog_t,*kern_t,*mem_t;
typedef int cl_int; typedef unsigned cl_uint;
typedef unsigned long cl_ulong; typedef unsigned cl_bool;
#define CL_SUCCESS 0
#define CL_DEVICE_TYPE_GPU 4ul
#define CL_MEM_READ_WRITE  1ul
#define CL_TRUE 1u
typedef cl_int(*f_getPIDs)(cl_uint,plat_t*,cl_uint*);
typedef cl_int(*f_getDIDs)(plat_t,cl_ulong,cl_uint,dev_t*,cl_uint*);
typedef ctx_t (*f_mkCtx)(const cl_uint*,cl_uint,const dev_t*,void*,void*,cl_int*);
typedef q_t   (*f_mkQ)(ctx_t,dev_t,cl_ulong,cl_int*);
typedef prog_t(*f_mkProg)(ctx_t,cl_uint,const char**,const size_t*,cl_int*);
typedef cl_int(*f_build)(prog_t,cl_uint,const dev_t*,const char*,void*,void*);
typedef kern_t(*f_mkKern)(prog_t,const char*,cl_int*);
typedef mem_t (*f_mkBuf)(ctx_t,cl_ulong,size_t,void*,cl_int*);
typedef cl_int(*f_setArg)(kern_t,cl_uint,size_t,const void*);
typedef cl_int(*f_wrBuf)(q_t,mem_t,cl_bool,size_t,size_t,const void*,cl_uint,const void*,void*);
typedef cl_int(*f_enqNDR)(q_t,kern_t,cl_uint,const size_t*,const size_t*,const size_t*,cl_uint,const void*,void*);
typedef cl_int(*f_rdBuf)(q_t,mem_t,cl_bool,size_t,size_t,void*,cl_uint,const void*,void*);
typedef cl_int(*f_fin)(q_t);
/* HF-03: campo e nome de simbolo separados */
#define _SYM(f,sym) _D.f=(f_##f)dlsym(_D.lib,(sym))
static struct{
  void *lib; plat_t plt; dev_t dev; ctx_t ctx;
  q_t q; kern_t k; mem_t b;
  f_getPIDs getPIDs; f_getDIDs getDIDs; f_mkCtx mkCtx;
  f_mkQ mkQ; f_mkProg mkProg; f_build build;
  f_mkKern mkKern; f_mkBuf mkBuf; f_setArg setArg;
  f_wrBuf wrBuf; f_enqNDR enqNDR; f_rdBuf rdBuf; f_fin fin;
} _D;
static const char _K[]=
"__kernel void r7(__global uint*s,uint K,uint cy){"
"int i=get_global_id(0);if(i>=7)return;"
"uint v=((ulong)s[i]*(ulong)K)>>16;"
"v=(v+s[(i+1u)%7u])&0xFFFFu;"
"barrier(CLK_GLOBAL_MEM_FENCE);s[i]=v;}";
static const char*_P[]={
  "/system/vendor/lib/libOpenCL.so",
  "/system/lib/libOpenCL.so",
  "/vendor/lib/libOpenCL.so",
  "/system/vendor/lib64/libOpenCL.so",
  "/vendor/lib64/libOpenCL.so",
  "/data/data/com.termux/files/usr/lib/libOpenCL.so",0};
int g_cl_init(gctx_t *c){
  int i; void *h=0;
  for(i=0;_P[i];i++){h=dlopen(_P[i],1);if(h)break;}
  if(!h)return 0; _D.lib=h;
  _SYM(getPIDs,"clGetPlatformIDs");
  _SYM(getDIDs,"clGetDeviceIDs");
  _SYM(mkCtx,"clCreateContext");
  _SYM(mkQ,"clCreateCommandQueue");
  _SYM(mkProg,"clCreateProgramWithSource");
  _SYM(build,"clBuildProgram");
  _SYM(mkKern,"clCreateKernel");
  _SYM(mkBuf,"clCreateBuffer");
  _SYM(setArg,"clSetKernelArg");
  _SYM(wrBuf,"clEnqueueWriteBuffer");
  _SYM(enqNDR,"clEnqueueNDRangeKernel");
  _SYM(rdBuf,"clEnqueueReadBuffer");
  _SYM(fin,"clFinish");
  if(!_D.getPIDs||!_D.getDIDs||!_D.mkCtx)goto fail;
  cl_uint np=0;
  if(_D.getPIDs(1,&_D.plt,&np)!=CL_SUCCESS||!np)goto fail;
  cl_uint nd=0;
  if(_D.getDIDs(_D.plt,CL_DEVICE_TYPE_GPU,1,&_D.dev,&nd)!=CL_SUCCESS||!nd)goto fail;
  cl_int e=0;
  _D.ctx=_D.mkCtx(0,1,&_D.dev,0,0,&e);if(e)goto fail;
  _D.q=_D.mkQ(_D.ctx,_D.dev,0,&e);if(e)goto fail;
  const char*src=_K;size_t sl=sizeof(_K)-1;
  prog_t p=_D.mkProg(_D.ctx,1,&src,&sl,&e);if(e)goto fail;
  if(_D.build(p,1,&_D.dev,"-cl-mad-enable",0,0))goto fail;
  _D.k=_D.mkKern(p,"r7",&e);if(e)goto fail;
  _D.b=_D.mkBuf(_D.ctx,CL_MEM_READ_WRITE,7*4,0,&e);if(e)goto fail;
  c->cl[0]=_D.q;c->cl[1]=_D.k;c->cl[2]=_D.b;
  c->backend=G_CL;return 1;
fail:dlclose(h);_D.lib=0;return 0;}
int g_cl_run(gctx_t*c,uint32_t ci,uint32_t hi,uint32_t cy){
  if(!_D.lib)return 0;
  uint32_t K=G_SPIRAL;
  if(_D.wrBuf(_D.q,_D.b,CL_TRUE,0,7*4,c->st.s,0,0,0))return 0;
  _D.setArg(_D.k,0,sizeof(mem_t),&_D.b);
  _D.setArg(_D.k,1,sizeof(uint32_t),&K);
  _D.setArg(_D.k,2,sizeof(uint32_t),&cy);
  size_t gsz=7,lsz=7;
  if(_D.enqNDR(_D.q,_D.k,1,0,&gsz,&lsz,0,0,0))return 0;
  if(_D.rdBuf(_D.q,_D.b,CL_TRUE,0,7*4,c->st.s,0,0,0))return 0;
  _D.fin(_D.q);
  c->st.coh=g_ema(c->st.coh,ci);c->st.ent=g_ema(c->st.ent,hi);
  c->st.phi=g_phi_q(c->st.ent,c->st.coh);
  c->st.phase=(c->st.phase+1u>=G_PERIOD)?0u:c->st.phase+1u;
  c->st.step++;g_state_seal(&c->st);return 1;}
void g_cl_close(gctx_t*c){
  if(_D.lib){dlclose(_D.lib);_D.lib=0;}
  c->cl[0]=c->cl[1]=c->cl[2]=0;}
