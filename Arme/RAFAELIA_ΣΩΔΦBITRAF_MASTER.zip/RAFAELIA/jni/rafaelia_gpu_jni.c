#include <jni.h>
#include "../gpu/rafaelia_gpu.h"
#include <string.h>
#ifdef __ANDROID__
#include <android/log.h>
#define LI(...) __android_log_print(3,"RafGPU",__VA_ARGS__)
#else
#define LI(...) (void)0
#endif
static gctx_t G __attribute__((aligned(64)));
static uint8_t _rdy=0;
JNIEXPORT jint JNICALL
Java_com_termux_rafaelia_RafaeliaCore_gpuInitNative(JNIEnv*e,jclass c){
  (void)e;(void)c;if(_rdy)return(jint)G.backend;
  g_init(&G);int b=g_detect(&G);_rdy=1;LI("backend=%d",b);return(jint)b;}
JNIEXPORT jint JNICALL
Java_com_termux_rafaelia_RafaeliaCore_gpuStepNative(JNIEnv*e,jclass c,jobject in,jint len){
  (void)c;if(!_rdy)return -1;
  uint8_t*p=(uint8_t*)(*e)->GetDirectBufferAddress(e,in);
  if(!p||len<=0)return -1;
  if(!g_step(&G,p,(uint32_t)len))return -2;return(jint)G.st.phi;}
JNIEXPORT jint JNICALL
Java_com_termux_rafaelia_RafaeliaCore_gpuBurstNative(JNIEnv*e,jclass c,jobject in,jint len,jint cy){
  (void)c;if(!_rdy||cy<=0)return -1;
  uint8_t*p=(uint8_t*)(*e)->GetDirectBufferAddress(e,in);
  if(!p||len<=0)return -1;
  uint32_t ci=g_crc32(p,(uint32_t)len)&0xFFFFu;
  uint32_t hi=g_entropy(p,(uint32_t)len);
  G.st.coh=g_ema(G.st.coh,ci);G.st.ent=g_ema(G.st.ent,hi);
  g_neon_burst(&G.st,(uint32_t)cy);
  G.st.phi=g_phi_q(G.st.ent,G.st.coh);g_state_seal(&G.st);
  return(jint)G.st.phi;}
JNIEXPORT jint JNICALL
Java_com_termux_rafaelia_RafaeliaCore_gpuStateNative(JNIEnv*e,jclass c,jobject out,jint cap){
  (void)c;if(!_rdy||cap<(jint)sizeof(gstate_t))return -1;
  uint8_t*p=(uint8_t*)(*e)->GetDirectBufferAddress(e,out);
  if(!p)return -1;memcpy(p,&G.st,sizeof(gstate_t));
  return(jint)sizeof(gstate_t);}
JNIEXPORT jint JNICALL
Java_com_termux_rafaelia_RafaeliaCore_gpuPhiNative(JNIEnv*e,jclass c){
  (void)e;(void)c;return _rdy?(jint)G.st.phi:0;}
JNIEXPORT void JNICALL
Java_com_termux_rafaelia_RafaeliaCore_gpuCloseNative(JNIEnv*e,jclass c){
  (void)e;(void)c;if(_rdy){g_close(&G);_rdy=0;}}
