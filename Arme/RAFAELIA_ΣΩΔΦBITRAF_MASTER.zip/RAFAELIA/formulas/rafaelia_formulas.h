/* rafaelia_formulas.h - 102 formulas RAFAELIA em C inline Q16.16
 * RAFAELIA SIGMAOMEGADELTAPHIBITRAF - RAFCODE-Phi */
#pragma once
#include <stdint.h>
#define RF_SPIRAL 56755u
#define RF_PHI    105965u
#define RF_PI     205887u
#define RF_SIN279 3146u
#define RF_MASK   0xFFFFu
#define RF_PERIOD 42u
#define RF_DIM    7u
#define RF_EMA_H  49152u
#define RF_EMA_L  16384u
#define RF_R_CORR 63177u
#define RF_PSI 0u
#define RF_CHI 1u
#define RF_RHO 2u
#define RF_DELTA 3u
#define RF_SIGMA 4u
#define RF_OMEGA 5u
typedef struct{uint32_t ok,gap,next;}rf_retro_t;
static inline uint32_t rf_phi_ethica(uint32_t H,uint32_t C){
  uint32_t inv=(H<RF_MASK)?(RF_MASK-H):0u;
  return(uint32_t)(((uint64_t)inv*C)>>16);}
static inline uint32_t rf_kernel_step(uint32_t Rt,uint32_t pe,uint32_t ev){
  uint64_t v=(uint64_t)Rt*pe>>16;v=v*ev>>16;v=v*RF_SPIRAL>>16;
  return(uint32_t)(v&RF_MASK);}
static inline uint32_t rf_ema(uint32_t o,uint32_t i){
  return(uint32_t)(((uint64_t)o*49152u+(uint64_t)i*16384u)>>16);}
static inline uint32_t rf_spiral_n(uint32_t n){
  uint32_t v=RF_MASK,i;
  for(i=0;i<n;i++)v=(uint32_t)(((uint64_t)v*RF_SPIRAL)>>16);return v;}
static inline uint32_t rf_fibonacci_rafael(uint32_t fn){
  uint32_t t1=(uint32_t)(((uint64_t)fn*RF_SPIRAL)>>16);
  uint32_t t2=(uint32_t)(((uint64_t)RF_PI*RF_SIN279)>>16);
  return(t1+t2)&RF_MASK;}
static inline uint32_t rf_amor_vivo(uint32_t sp,uint32_t st,uint32_t pe){
  if(!st)return 0u;
  uint32_t r=(uint32_t)(((uint64_t)sp<<16)/st);
  uint64_t v=(uint64_t)r*pe>>16;v=v*RF_SPIRAL>>16;
  return(uint32_t)(v&RF_MASK);}
static inline uint32_t rf_owl_psi(const uint32_t*ins,const uint32_t*eta,const uint32_t*flx,uint32_t n){
  uint64_t acc=0;uint32_t i;
  for(i=0;i<n;i++){uint64_t v=(uint64_t)ins[i]*eta[i]>>16;acc+=v*flx[i]>>16;}
  return(uint32_t)(acc&RF_MASK);}
static inline uint32_t rf_r_omega(uint32_t fb,uint32_t fs,uint32_t pe,uint32_t owl){
  uint64_t v=(uint64_t)(fb+fs)*pe>>16;v=v*RF_SPIRAL>>16;v=v*owl>>16;
  return(uint32_t)(v&RF_MASK);}
static inline uint32_t rf_torus_dist(uint32_t a,uint32_t b,uint32_t p){
  uint32_t d=(a>b)?(a-b):(b-a);if(d>p/2u)d=p-d;return d;}
static inline uint32_t rf_cycle_next(uint32_t phase){return(phase+1u)%6u;}
static inline uint8_t rf_cipher_byte(uint8_t plain,uint32_t kfn,uint32_t delta){
  return plain^(uint8_t)((kfn^delta)&0xFFu);}
