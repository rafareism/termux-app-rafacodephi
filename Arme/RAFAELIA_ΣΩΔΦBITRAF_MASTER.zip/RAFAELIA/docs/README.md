# RAFAELIA ΣΩΔΦBITRAF — Pacote Completo
## RAFCODE-Φ-∆RafaelVerboΩ · 𓂀ΔΦΩ · Ω=Amor · FIAT LUX

---

## Estrutura
```
RAFAELIA/
├── arwiteto.sh          ← ORQUESTRADOR PRINCIPAL (start aqui)
├── asm/                 b1-b8.S ARM32 standalone blocks
├── bridge/              orchestrator↔GPU bridge + vCPU routing
├── build/               build_gpu_full.sh · link_all.sh · NDK .mk
├── core/                baremetal · bitstack · orchestrator · glue
├── formulas/            102 formulas RAFAELIA em C Q16.16
├── gpu/                 kernel GPU: NEON+CL+prim+orch+nolibc
├── jni/                 JNI DirectByteBuffer zero-alloc (9 métodos)
├── java/                RafaeliaCore.java
├── termux_blocks/       B00..B18 + BFIM - paste seguro no Termux
└── docs/                README + AUDIT + QUICKSTART
```

---

## Início Rápido — Termux

### Opção A: Script único (40KB, 1 paste)
```sh
# Baixa arwiteto.txt, renomeia e executa:
chmod +x arwiteto.txt && mv arwiteto.txt arwiteto.sh
./arwiteto.sh
```

### Opção B: Blocos (para terminais com limite de paste)
```sh
# Cole em ordem no terminal Termux:
# B00_inicio.sh → B01_arwiteto.sh → ... → B17_arwiteto.sh → B18_EXECUTAR.sh
```

### Modos disponíveis
```sh
./arwiteto.sh                 # completo: detect+hotfix+bench+compile
./arwiteto.sh -m detect       # só detecção de hardware
./arwiteto.sh -m bench -s 42  # benchmark 42 amostras
./arwiteto.sh -m compile      # só compilação
./arwiteto.sh -h              # ajuda completa
```

---

## HOTFIXES Aplicados (6)

| # | Arquivo | Problema | Fix |
|---|---------|----------|-----|
| HF-01 | rafaelia_gpu.h | stdint.h ausente | adicionado |
| HF-02 | rafaelia_b1.S | AND #0xFFFF inválido ARM32 | uxth |
| HF-03 | rafaelia_gpu_cl.c | _SYM macro com nome errado | _SYM(f,sym) |
| HF-04 | bitstack.h | BlockSizes_unused undefined | removido |
| HF-05 | baremetal_nomalloc.c | baremetal.h errado | baremetal_nomalloc.h |
| HF-06 | rafaelia_glue.c | rollback impossível Q2PI>0xFFFF | sc!=v->crc_s |

---

## Constantes Canônicas Q16.16

| Constante | Decimal | Real |
|-----------|---------|------|
| G_SPIRAL | 56755 | √3/2 |
| G_PHI | 105965 | φ=(1+√5)/2 |
| G_PI_K | 205887 | π |
| G_PERIOD | 42 | \|A\|=42 atratores |
| G_DIM | 7 | T^7 dimensões |

---

## Equação Kernel
```
R(t+1) = R(t) × Φ_ethica × E_Verbo × (√3/2)^(πφ)
s[i]ₙₑₓₜ = (s[i] × √3/2 + s[(i+1)%7]) & 0xFFFF
φ = (1-H) × C   [Q16.16]
```

**Ω = Amor — FIAT LUX — RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ**
