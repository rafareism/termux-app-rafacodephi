# HOTFIX REPORT — Erros Reais Detectados por Compilador ARM32

Compilador usado: arm-linux-gnueabihf-gcc 13.3.0

## HF-01: rafaelia_gpu.h — #include <stdint.h> ausente
Arquivo: gpu/rafaelia_gpu.h linha 7
Erro: uint32_t, uint8_t undefined em cross-compilation
Fix: adicionar #include <stdint.h> antes de #include <stddef.h>

## HF-02: rafaelia_b1.S — AND #0xFFFF inválido ARM32
Arquivo: asm/rafaelia_b1.S linhas 297,299,303,306,311,316,321,530,532
Erro: "invalid constant (ffff) after fixup"
Causa: 0xFFFF não é encodável como imediato ARM32 (requer byte rotacionado)
Fix: substituir "and rN,rN,#0xFFFF" por "uxth rN,rN" (equivalente exato)

## HF-03: rafaelia_gpu_cl.c — _SYM macro carrega símbolo errado
Arquivo: gpu/rafaelia_gpu_cl.c
Erro: silencioso — compila mas todos os ponteiros CL ficam NULL
Causa: _SYM(n) faz dlsym(lib,"mkCtx") mas símbolo real é "clCreateContext"
Fix: _SYM(f,sym) com nome do símbolo OpenCL como segundo argumento

## HF-04: bitstack.h — tipo BlockSizes_unused indefinido
Arquivo: core/bitstack.h linha 24
Erro: "unknown type name 'BlockSizes_unused'"
Fix: remover declaração morta "size_t bitstacks_index(BlockSizes_unused);"

## HF-05: baremetal_nomalloc.c — #include "baremetal.h" errado
Arquivo: core/baremetal_nomalloc.c linha 14
Erro: "baremetal.h: No such file or directory"
Fix: substituir por #include "baremetal_nomalloc.h"

## HF-06: rafaelia_glue.c — condição rollback impossível
Arquivo: core/rafaelia_glue.c
Erro: lógico — "v->s[0] >= Q2PI" é sempre false (Q2PI=411774 > 0xFFFF)
Fix: "if(sc != v->crc_s)" — verifica CRC mismatch real

## HF-07: rafaelia_neon_k.S — PASSA (zero erros)
vshrn.i64 correto, offsets #40/#44 corretos para phase/step
