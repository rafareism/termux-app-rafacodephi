#pragma once
#include <stdint.h>
#include "../gpu/rafaelia_gpu.h"
void     raf_bridge_init    (void);
int      raf_vcpu_dispatch  (uint32_t vcpu_id,const uint8_t*data,uint32_t len);
uint32_t raf_phi_read       (void);
uint32_t raf_phase_read     (void);
uint32_t raf_crc_read       (void);
uint32_t raf_routing_next   (uint32_t current_vcpu);
uint32_t raf_layer_for_vcpu (uint32_t vcpu_id);
void     raf_burst_all      (const uint8_t*seed,uint32_t seed_len);
void     raf_state_snapshot (gstate_t *out);
void     raf_reset          (void);
