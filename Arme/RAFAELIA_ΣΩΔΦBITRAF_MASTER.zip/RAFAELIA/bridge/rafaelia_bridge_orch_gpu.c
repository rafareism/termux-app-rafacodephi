#include "rafaelia_bridge_orch_gpu.h"
#include <string.h>
static gctx_t _G __attribute__((aligned(64)));
static uint8_t _rdy=0;
static const uint32_t _hz[8]={56755u,63805u,71710u,80573u,90527u,101747u,114338u,128418u};
#define THR_L1 90000u
#define THR_L2 70000u
#define THR_BF 56000u
void raf_bridge_init(void){
  if(_rdy)return;g_init(&_G);g_detect(&_G);_rdy=1;}
int raf_vcpu_dispatch(uint32_t id,const uint8_t*data,uint32_t len){
  if(!_rdy)raf_bridge_init();if(id>=8u||!data||!len)return -1;
  uint32_t hz=_hz[id&7u];
  uint32_t cin=g_crc32(data,len)&0xFFFFu;
  uint32_t w=(uint32_t)(((uint64_t)cin*hz)>>16)&0xFFFFu;
  _G.st.coh=g_ema(_G.st.coh,w);
  return g_step(&_G,data,len);}
uint32_t raf_phi_read(void){return _rdy?_G.st.phi:0u;}
uint32_t raf_phase_read(void){return _rdy?_G.st.phase:0u;}
uint32_t raf_crc_read(void){return _rdy?_G.st.crc:0u;}
uint32_t raf_routing_next(uint32_t cur){
  if(!_rdy)return 0u;
  uint32_t stride=(_G.st.phase%2u==0u)?3u:5u;
  return(cur+stride)&7u;}
uint32_t raf_layer_for_vcpu(uint32_t id){
  uint32_t hz=_hz[id&7u];
  if(hz>=THR_L1)return 0u;if(hz>=THR_L2)return 1u;
  if(hz>=THR_BF)return 2u;return 3u;}
void raf_burst_all(const uint8_t*seed,uint32_t len){
  if(!_rdy)raf_bridge_init();
  uint32_t v=0,i;
  for(i=0;i<42u;i++){raf_vcpu_dispatch(v,seed,len);v=raf_routing_next(v);}}
void raf_state_snapshot(gstate_t*out){if(!_rdy||!out)return;*out=_G.st;}
void raf_reset(void){g_state_init(&_G.st);}
