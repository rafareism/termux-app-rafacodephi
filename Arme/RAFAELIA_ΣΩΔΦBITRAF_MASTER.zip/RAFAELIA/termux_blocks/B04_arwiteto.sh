cat >> arwiteto.txt << 'ARW04'
    # Memory
    MEM_TOTAL_KB=$(awk '/^MemTotal/{print $2}' /proc/meminfo 2>/dev/null || echo 0)
}

detect_caps() {
    local cpu; cpu=$(cat /proc/cpuinfo 2>/dev/null)
    # NEON / ASIMD
    echo "$cpu" | grep -qi 'neon\|asimd\|Advanced SIMD' && HAS_NEON=1
    echo "$cpu" | grep -qi 'asimd'                       && HAS_ASIMD=1
    echo "$cpu" | grep -qi 'sve'                         && HAS_SVE=1
    echo "$cpu" | grep -qi 'crc32'                       && HAS_CRC32=1

    # CPU frequencies
    local f0="/sys/devices/system/cpu/cpu0/cpufreq"
    if [ -f "${f0}/cpuinfo_max_freq" ]; then
        CPU_FREQ_MAX=$(cat "${f0}/cpuinfo_max_freq" 2>/dev/null || echo 0)
    fi
    if [ -f "${f0}/cpuinfo_min_freq" ]; then
        CPU_FREQ_MIN=$(cat "${f0}/cpuinfo_min_freq" 2>/dev/null || echo 0)
    fi
}

detect_os() {
    OS_NAME=$(uname -o 2>/dev/null || uname -s 2>/dev/null || echo "Unknown")
    # Termux
    if [ -d "/data/data/com.termux" ] || [ -n "${TERMUX_VERSION}" ]; then
        IS_TERMUX=1
    fi
    # Android
    if [ -f "/system/build.prop" ] || command -v getprop >/dev/null 2>&1; then
        IS_ANDROID=1
        ANDROID_VER=$(getprop ro.build.version.release 2>/dev/null || \
            grep 'ro.build.version.release' /system/build.prop 2>/dev/null | \
            cut -d= -f2 || echo "?")
    fi
}

detect_compiler() {
    local candidates="clang gcc cc"
    local c
    for c in $candidates; do
        if command -v "$c" >/dev/null 2>&1; then
            CC_BIN="$c"
            break
        fi
    done

    for c in "llvm-as" "as" "arm-linux-gnueabihf-as"; do
        if command -v "$c" >/dev/null 2>&1; then
            AS_BIN="$c"
            break
        fi
    done

    # Build compiler flags by arch
    case "$ARCH" in
        arm64)
            CC_FLAGS="-march=armv8-a -O2 -std=c11 -fno-stack-protector"
            [ "$HAS_NEON" = "1" ] && CC_FLAGS="$CC_FLAGS -DHAS_NEON"
            [ "$HAS_CRC32" = "1" ] && CC_FLAGS="$CC_FLAGS -march=armv8-a+crc"
            ;;
        arm32)
            CC_FLAGS="-march=armv7-a -mfpu=neon-vfpv4 -mfloat-abi=softfp"
            CC_FLAGS="$CC_FLAGS -O2 -std=c11 -fno-stack-protector"
            [ "$HAS_NEON" = "1" ] && CC_FLAGS="$CC_FLAGS -DHAS_NEON"

ARW04
echo 'B04 OK (linhas 196-260)'
