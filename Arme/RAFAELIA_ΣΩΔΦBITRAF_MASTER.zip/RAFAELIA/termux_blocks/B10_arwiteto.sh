cat >> arwiteto.txt << 'ARW10'

    # Estatísticas
    local stats_line
    stats_line=$(bench_stats "$raw")

    section "RESULTADOS BENCHMARK"
    # Parse stats
    local n min max mean median std cv dist skew modal
    eval "$(echo "$stats_line" | tr ' ' '\n' | sed 's/=/="/;s/$/"/'  2>/dev/null || echo "")"
    # Fallback parse
    n=$(echo "$stats_line" | grep -o 'n=[^ ]*' | cut -d= -f2)
    min=$(echo "$stats_line" | grep -o 'min=[^ ]*' | cut -d= -f2)
    max=$(echo "$stats_line" | grep -o 'max=[^ ]*' | cut -d= -f2)
    mean=$(echo "$stats_line" | grep -o 'mean=[^ ]*' | cut -d= -f2)
    median=$(echo "$stats_line" | grep -o 'median=[^ ]*' | cut -d= -f2)
    std=$(echo "$stats_line" | grep -o 'std=[^ ]*' | cut -d= -f2)
    cv=$(echo "$stats_line" | grep -o 'cv=[^ ]*' | cut -d= -f2)
    dist=$(echo "$stats_line" | grep -o 'dist=[^ ]*' | cut -d= -f2)
    skew=$(echo "$stats_line" | grep -o 'skew=[^ ]*' | cut -d= -f2)
    modal=$(echo "$stats_line" | grep -o 'modal=[^ ]*' | cut -d= -f2)

    kv "Amostras (N):"        "${n}"
    kv "Mínimo:"              "${min} µs"
    kv "Máximo:"              "${max} µs"
    kv "Média:"               "${mean} µs"
    kv "Mediana:"             "${median} µs"
    kv "Moda:"                "${modal} µs"
    kv "Desvio Padrão:"       "${std} µs"
    kv "CV (coef. variação):" "${cv}"
    kv "Distribuição:"        "${dist}"
    kv "Assimetria:"          "${skew}"

    # Classificação colorida
    printf "\n ${C_PHI}${BOLD}━━ DIAGNÓSTICO SOC ━━${R}\n"
    case "$dist" in
        HOMOGENEO) printf " ${C_OK}● DETERMINÍSTICO${R} — CPU estável, throttle ausente\n" ;;
        ESTAVEL)   printf " ${C_INF}● ESTÁVEL${R} — variação aceitável para benchmark\n" ;;
        VARIAVEL)  printf " ${C_WRN}● VARIÁVEL${R} — possível throttle ou background load\n" ;;
        CAOTICO)   printf " ${C_ERR}● CAÓTICO${R} — interferência severa do SO/thermal\n" ;;
    esac

    # Histograma ASCII
    _bench_histogram "$raw"

    # Salva relatório
    echo "$stats_line" > "${ARW_BENCH_DIR}/stats.txt"
    echo "$soc_pre" > "${ARW_BENCH_DIR}/soc_pre.txt"
    echo "$soc_post" > "${ARW_BENCH_DIR}/soc_post.txt"
    log OK "Benchmark concluído → ${ARW_BENCH_DIR}/"
    heartbeat
}

_bench_histogram() {
    local file="$1"
    local cols=40
    awk -v cols="$cols" '
    /^[0-9]/{a[NR]=$1; if($1<mn||NR==1) mn=$1; if($1>mx) mx=$1}
    END {
        if(NR<2){exit}
        range=mx-mn; if(range==0) range=1
        nbkt=10
        bw=range/nbkt
        for(i=1;i<=NR;i++){b=int((a[i]-mn)/bw); if(b>=nbkt)b=nbkt-1; cnt[b]++}
        max_cnt=0
        for(b=0;b<nbkt;b++) if(cnt[b]>max_cnt) max_cnt=cnt[b]

ARW10
echo 'B10 OK (linhas 586-650)'
