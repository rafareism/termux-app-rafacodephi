cat >> arwiteto.txt << 'ARW05'
            ;;
        x86_64)
            CC_FLAGS="-march=native -O2 -std=c11 -fno-stack-protector"
            ;;
        x86)
            CC_FLAGS="-march=i686 -O2 -std=c11 -fno-stack-protector -m32"
            ;;
        *)
            CC_FLAGS="-O2 -std=c11"
            ;;
    esac
}

detect_all() {
    detect_arch
    detect_caps
    detect_os
    detect_compiler
}

show_detect() {
    section "DETECÇÃO DE HARDWARE / SOFTWARE"
    kv "Arquitetura:"    "$ARCH ($ABI)"
    kv "CPUs online:"    "$NCPU"
    kv "NEON/ASIMD:"     "$([ "$HAS_NEON" = "1" ] && echo "SIM" || echo "NAO")"
    kv "CRC32 HW:"       "$([ "$HAS_CRC32" = "1" ] && echo "SIM" || echo "NAO")"
    kv "SVE:"            "$([ "$HAS_SVE" = "1" ] && echo "SIM" || echo "NAO")"
    kv "Freq MAX:"       "$(echo "$CPU_FREQ_MAX" | awk '{printf "%.0f MHz", $1/1000}')"
    kv "Freq MIN:"       "$(echo "$CPU_FREQ_MIN" | awk '{printf "%.0f MHz", $1/1000}')"
    kv "Page size:"      "${PAGE_SZ} bytes"
    kv "RAM total:"      "$(echo "$MEM_TOTAL_KB" | awk '{printf "%.0f MB", $1/1024}')"
    kv "OS:"             "$OS_NAME"
    kv "Android:"        "$([ "$IS_ANDROID" = "1" ] && echo "v$ANDROID_VER" || echo "NAO")"
    kv "Termux:"         "$([ "$IS_TERMUX" = "1" ] && echo "SIM" || echo "NAO")"
    kv "Compilador:"     "${CC_BIN:-NAO ENCONTRADO}"
    kv "CC flags:"       "${CC_FLAGS:-N/A}"
    kv "Jobs paralelos:" "$OPT_JOBS"
}

# ═══════════════════════════════════════════════════════════════════════
# [5] WATCHDOG MODULE
# ═══════════════════════════════════════════════════════════════════════
watchdog_start() {
    mkdir -p "$ARW_HOME"
    echo "$$" > "$ARW_LOCK"
    date +%s > "$ARW_HB"

    # Background watchdog process
    (
        while true; do
            sleep 5
            # Verifica se processo principal ainda vive
            if ! kill -0 "$ARW_PID" 2>/dev/null; then
                exit 0
            fi
            # Verifica heartbeat
            if [ -f "$ARW_HB" ]; then
                local hb now age
                hb=$(cat "$ARW_HB" 2>/dev/null || echo 0)
                now=$(date +%s 2>/dev/null || echo 0)
                age=$((now - hb))
                if [ "$age" -gt "$OPT_WDOG_TIMEOUT" ]; then
                    # Timeout — força rollback
                    printf '\n[WATCHDOG] TIMEOUT %ds — iniciando rollback\n' \
                        "$OPT_WDOG_TIMEOUT" >> "$ARW_LOG" 2>/dev/null

ARW05
echo 'B05 OK (linhas 261-325)'
