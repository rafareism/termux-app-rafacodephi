cat >> arwiteto.txt << 'ARW11'
        printf "\n Histograma (µs)\n"
        for(b=0;b<nbkt;b++){
            lo=mn+b*bw; hi=lo+bw
            bar_len=int(cnt[b]*cols/max_cnt)
            printf " %6.0f-%-6.0f |", lo, hi
            for(k=0;k<bar_len;k++) printf "▪"
            printf " %d\n", cnt[b]+0
        }
    }' "$file"
}

# ═══════════════════════════════════════════════════════════════════════
# [9] PIPELINE MODULE — Detecção e compilação RAFAELIA
# ═══════════════════════════════════════════════════════════════════════
MODULES_FOUND=""
MODULES_OK=""
MODULES_FAIL=""

pipeline_detect() {
    section "DETECÇÃO DE MÓDULOS RAFAELIA"
    local src_dirs="${ARW_BUILD_DIR} ${PWD} ${HOME}/rafaelia_full/gpu \
                    ${HOME}/rafaelia_full/core ${HOME}/rafaelia_full/asm"

    local expected="rafaelia_gpu.h rafaelia_gpu_prim.c rafaelia_gpu_cl.c \
                     rafaelia_gpu_orch.c rafaelia_neon_k.S \
                     rafaelia_bridge_orch_gpu.c"

    for mod in $expected; do
        local found=0
        for d in $src_dirs; do
            if [ -f "${d}/${mod}" ]; then
                found=1
                MODULES_FOUND="${MODULES_FOUND} ${d}/${mod}"
                log OK "  $mod → ${d}/"
                break
            fi
        done
        [ "$found" = "0" ] && log WRN "  $mod → NÃO ENCONTRADO"
    done
    heartbeat
}

pipeline_apply_hotfixes() {
    section "HOTFIXES AUTOMÁTICOS"
    local hf_count=0

    # HF-01: stdint.h missing in rafaelia_gpu.h
    local h="${HOME}/rafaelia_full/gpu/rafaelia_gpu.h"
    if [ -f "$h" ] && ! grep -q 'include.*stdint.h' "$h"; then
        sed -i 's/#include <stddef.h>/#include <stdint.h>\n#include <stddef.h>/' "$h" 2>/dev/null && \
            { log OK "HF-01: stdint.h adicionado em rafaelia_gpu.h"; hf_count=$((hf_count+1)); }
    fi

    # HF-02: AND r0,r0,#0xFFFF → uxth r0,r0 em b1.S
    local b1="${HOME}/rafaelia_full/asm/rafaelia_b1.S"
    if [ -f "$b1" ] && grep -q 'and.*#0xFFFF' "$b1"; then
        sed -i 's/and\([[:space:]]*\)r\([0-9]\),.*#0xFFFF/uxth r\2, r\2/g' "$b1" 2>/dev/null && \
            { log OK "HF-02: uxth substitui AND #0xFFFF em rafaelia_b1.S"; hf_count=$((hf_count+1)); }
    fi

    # HF-04: bitstacks_index(BlockSizes_unused) → remover
    local bsh="${HOME}/rafaelia_full/core/bitstack.h"
    if [ -f "$bsh" ] && grep -q 'BlockSizes_unused' "$bsh"; then
        sed -i '/BlockSizes_unused/d' "$bsh" 2>/dev/null && \
            { log OK "HF-04: declaração morta removida de bitstack.h"; hf_count=$((hf_count+1)); }

ARW11
echo 'B11 OK (linhas 651-715)'
