#!/bin/sh
# ARWITETO - Bloco B00: INICIO
# Cole os blocos em ordem: B00, B01, B02 ... BFIM
rm -f arwiteto.txt
echo "B00 OK - arquivo iniciado"
