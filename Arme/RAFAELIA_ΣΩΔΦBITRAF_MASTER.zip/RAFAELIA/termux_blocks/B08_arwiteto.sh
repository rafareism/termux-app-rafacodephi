cat >> arwiteto.txt << 'ARW08'
    [ -z "$CC_BIN" ] && return 1
    local src="${ARW_BENCH_DIR}/probe.c"
    printf 'int x(int n){return n?x(n-1)+1:0;}int main(){return x(1000);}' > "$src"
    local t0 t1
    t0=$(_now_ns)
    "$CC_BIN" $CC_FLAGS "$src" -o "${ARW_BENCH_DIR}/probe" 2>/dev/null && true
    t1=$(_now_ns)
    rm -f "$src" "${ARW_BENCH_DIR}/probe"
    echo $(( (t1 - t0) / 1000000 ))  # ms
}

# Pré-aquecimento SOC
bench_warmup() {
    local secs="${OPT_WARMUP}"
    local t0 t_now elapsed i=0
    t0=$(date +%s 2>/dev/null || echo 0)
    log INF "Pré-aquecimento SOC ${secs}s (stabiliza freq/temp)..."
    while true; do
        # Loop compute intensivo
        _bench_kernel_shell 10000 > /dev/null
        i=$(( i + 1 ))
        t_now=$(date +%s 2>/dev/null || echo 0)
        elapsed=$(( t_now - t0 ))
        pct=$(( elapsed * 100 / secs ))
        [ "$pct" -gt 100 ] && pct=100
        progress_bar "$pct" "warmup ${elapsed}s/${secs}s   "
        [ "$elapsed" -ge "$secs" ] && break
        heartbeat
    done
    printf '\n'
    log OK "Warmup concluído: $i iterações"
    heartbeat
}

# Coleta uma amostra de tempo em microsegundos
bench_sample() {
    local t0 t1 delta
    t0=$(_now_ns)
    _bench_kernel_shell "$OPT_PREWARM_ITER" > /dev/null
    t1=$(_now_ns)
    delta=$(( (t1 - t0) / 1000 ))  # µs
    echo "$delta"
}

# Estatísticas via awk — retorna: min max mean median stddev cv dist modal
bench_stats() {
    # $1 = arquivo com uma amostra por linha (µs)
    local file="$1"
    awk '
    BEGIN {n=0; sum=0; sum2=0; min=999999999; max=0}
    /^[0-9]/{
        v=$1; n++; sum+=v; sum2+=v*v
        if(v<min) min=v
        if(v>max) max=v
        a[n]=v
    }
    END {
        if(n==0){print "ERR"; exit}
        mean=sum/n
        var=(sum2/n)-(mean*mean)
        std=(var>0)?sqrt(var):0
        # Sort bubble para mediana e moda
        for(i=1;i<=n;i++) for(j=i+1;j<=n;j++) {
            if(a[i]>a[j]){t=a[i];a[i]=a[j];a[j]=t}
        }

ARW08
echo 'B08 OK (linhas 456-520)'
