cat >> arwiteto.txt << 'ARW06'
                    rollback_restore "last"
                    kill -TERM "$ARW_PID" 2>/dev/null
                    exit 1
                fi
            fi
        done
    ) &
    ARW_WDOG_PID=$!
    log DIM "Watchdog PID=$ARW_WDOG_PID timeout=${OPT_WDOG_TIMEOUT}s"
}

watchdog_stop() {
    [ -n "$ARW_WDOG_PID" ] && kill "$ARW_WDOG_PID" 2>/dev/null
    rm -f "$ARW_LOCK" "$ARW_HB"
}

heartbeat() {
    date +%s > "$ARW_HB" 2>/dev/null
}

# ═══════════════════════════════════════════════════════════════════════
# [6] ROLLBACK MODULE
# ═══════════════════════════════════════════════════════════════════════
rollback_save() {
    local name="${1:-auto}"
    local dir="${ARW_CKPT}/${name}"
    mkdir -p "$dir"
    # Salva estado atual
    echo "$ARCH $ABI $NCPU $HAS_NEON $HAS_CRC32" > "${dir}/hw_state"
    echo "$CC_BIN $CC_FLAGS"                       > "${dir}/cc_state"
    date +%s                                        > "${dir}/ts"
    [ -d "$ARW_BUILD_DIR" ] && \
        cp -r "$ARW_BUILD_DIR" "${dir}/build_snap" 2>/dev/null
    log DIM "Checkpoint salvo: $name"
    heartbeat
}

rollback_restore() {
    local name="${1:-last}"
    local dir="${ARW_CKPT}/${name}"
    if [ ! -d "$dir" ]; then
        # Tenta o mais recente
        dir=$(ls -1dt "${ARW_CKPT}"/*/  2>/dev/null | head -1)
    fi
    if [ -d "$dir" ]; then
        [ -d "${dir}/build_snap" ] && \
            cp -r "${dir}/build_snap" "$ARW_BUILD_DIR" 2>/dev/null
        log WRN "Rollback restaurado de: $dir"
        return 0
    fi
    log ERR "Nenhum checkpoint para restaurar"
    return 1
}

rollback_list() {
    section "CHECKPOINTS DISPONÍVEIS"
    ls -1t "${ARW_CKPT}/" 2>/dev/null | while read -r n; do
        local ts; ts=$(cat "${ARW_CKPT}/${n}/ts" 2>/dev/null || echo "?")
        kv "$n" "$(date -d "@$ts" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "$ts")"
    done
}

# ═══════════════════════════════════════════════════════════════════════
# [7] SOC THERMAL / FREQ MONITOR
# ═══════════════════════════════════════════════════════════════════════

ARW06
echo 'B06 OK (linhas 326-390)'
