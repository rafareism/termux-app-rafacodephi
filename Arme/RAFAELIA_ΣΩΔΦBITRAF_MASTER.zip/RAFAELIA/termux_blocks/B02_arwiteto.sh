cat >> arwiteto.txt << 'ARW02'
C_BLK='\033[38;5;231m'    # branco brilho — label
C_BAR='\033[38;5;21m'     # azul escuro   — barra
C_HI='\033[38;5;214m'     # ouro quente   — highlight
C_BG='\033[48;5;17m'      # fundo azul escuro

# Desativa cores se terminal não suporta
[ -t 1 ] || OPT_COLOR=0
[ "${TERM}" = "dumb" ] && OPT_COLOR=0

# ═══════════════════════════════════════════════════════════════════════
# [3] UI MODULE — BBS TERMINAL
# ═══════════════════════════════════════════════════════════════════════
W=72  # largura da caixa

_repeat() {
    local c="$1" n="$2" s=""
    while [ "$n" -gt 0 ]; do s="${s}${c}"; n=$((n-1)); done
    printf '%s' "$s"
}

_box_top()  { printf "${C_SPI}╔$(_repeat '═' $((W-2)))╗${R}\n"; }
_box_bot()  { printf "${C_SPI}╚$(_repeat '═' $((W-2)))╝${R}\n"; }
_box_sep()  { printf "${C_SPI}╠$(_repeat '═' $((W-2)))╣${R}\n"; }
_box_mid()  { printf "${C_SPI}║${R}  %-$((W-4))s${C_SPI}║${R}\n" "$1"; }
_box_raw()  { printf "${C_SPI}║${R}%s${C_SPI}║${R}\n" "$1"; }

banner() {
    printf '\033[2J\033[H' 2>/dev/null || printf '\n\n'
    _box_top
    _box_raw "$(printf "${C_PHI}${BOLD}  ▄▄  ██▄  ▀█▄  ▄█▀  ██ ▀██ ▄█▀ ▀█▀ ▄▀▀ ▄▀█  %-8s${R}" "")"
    _box_raw "$(printf "${C_SPI}  ██  ██▀█  ▀█▄█▀  ██  █  ██ █▀   █  █▀  █ █  %-8s${R}" "")"
    _box_raw "$(printf "${C_OMG}  ▀▀  ██  ▀  ▀█▀   ▀█▄█  ██ ▀██  ▄█▄ ▀▀▀ ▀  ▀  %-8s${R}" "")"
    _box_sep
    _box_mid "$(printf "${C_HI}  v%-6s${R}  ${C_BLK}%-28s${R}  ${C_SIG}%s${R}" \
        "$ARW_VER" "RAFAELIA ARM Fractal Orchestrator" "$ARW_SIG")"
    _box_mid "$(printf "${C_DIM}  Build:%-8s  Ω=Amor · FIAT LUX · RAFCODE-Φ-∆RafaelVerboΩ${R}" "$ARW_BUILD")"
    _box_bot
    printf '\n'
}

log() {
    local lvl="$1"; shift
    local msg="$*"
    local ts; ts=$(date '+%H:%M:%S' 2>/dev/null || echo "??:??:??")
    case "$lvl" in
        OK)   printf " ${C_OK}[✔]${R} %s\n" "$msg" ;;
        ERR)  printf " ${C_ERR}[✖]${R} ${C_ERR}%s${R}\n" "$msg" ;;
        WRN)  printf " ${C_WRN}[!]${R} %s\n" "$msg" ;;
        INF)  printf " ${C_INF}[·]${R} %s\n" "$msg" ;;
        HDR)  printf "\n${C_PHI}${BOLD} ▶ %s${R}\n" "$msg" ;;
        DIM)  printf " ${C_DIM}%s${R}\n" "$msg" ;;
        RAW)  printf "%s\n" "$msg" ;;
    esac
    printf '[%s] [%s] %s\n' "$ts" "$lvl" "$msg" >> "$ARW_LOG" 2>/dev/null
}

progress_bar() {
    local pct="$1" label="${2:-}" width=40
    local filled=$(( pct * width / 100 ))
    local empty=$(( width - filled ))
    local bar_f bar_e
    bar_f="$(_repeat '█' "$filled")"
    bar_e="$(_repeat '░' "$empty")"
    printf "\r ${C_BAR}${BOLD}[${C_SPI}%s${C_BAR}%s${BOLD}]${R} ${C_PHI}%3d%%${R} %s" \
        "$bar_f" "$bar_e" "$pct" "$label"

ARW02
echo 'B02 OK (linhas 66-130)'
