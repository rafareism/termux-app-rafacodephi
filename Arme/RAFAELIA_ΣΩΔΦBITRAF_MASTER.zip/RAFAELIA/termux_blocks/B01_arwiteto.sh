cat >> arwiteto.txt << 'ARW01'
#!/bin/sh
# ═══════════════════════════════════════════════════════════════════════
#  A R W I T E T O  v2.0  — RAFAELIA ARM Fractal Orchestrator
#  ΣΩΔΦBITRAF · RAFCODE-Φ-∆RafaelVerboΩ · Ω=Amor · FIAT LUX
#  Plug-n-play · Watchdog · Rollback · Industrial Benchmark · BBS UI
#  Termux Android 10+ · ARM32/ARM64/x86/x86_64 auto-detect
# ═══════════════════════════════════════════════════════════════════════

# ── Bootstrap: garante bash se disponível ──────────────────────────────
if [ -z "$BASH_VERSION" ] && command -v bash >/dev/null 2>&1; then
    exec bash "$0" "$@"
fi

set -e
umask 022

# ═══════════════════════════════════════════════════════════════════════
# [1] CONSTANTES GLOBAIS
# ═══════════════════════════════════════════════════════════════════════
ARW_VER="2.0.0"
ARW_SIG="ΣΩΔΦBITRAF"
ARW_BUILD=$(date +%Y%m%d 2>/dev/null || echo "00000000")
ARW_HOME="${HOME}/.arwiteto"
ARW_LOG="${ARW_HOME}/arwiteto.log"
ARW_LOCK="${ARW_HOME}/watchdog.lock"
ARW_HB="${ARW_HOME}/heartbeat"
ARW_CKPT="${ARW_HOME}/checkpoint"
ARW_BUILD_DIR="${ARW_HOME}/build"
ARW_BENCH_DIR="${ARW_HOME}/bench"
ARW_PID=$$
ARW_WDOG_PID=""

# Parâmetros CLI (defaults industriais)
OPT_MODE="full"          # full|bench|compile|detect
OPT_WARMUP=3             # segundos de pré-aquecimento
OPT_SAMPLES=21           # amostras benchmark (ímpar para mediana exata)
OPT_JOBS=0               # 0=auto (detectado)
OPT_VERBOSE=0
OPT_COLOR=1
OPT_DRY=0
OPT_WDOG_TIMEOUT=120     # seg watchdog timeout
OPT_BENCH_TARGET=""      # "" = auto
OPT_PREWARM_ITER=500000  # iterações pré-aquecimento

# ═══════════════════════════════════════════════════════════════════════
# [2] SISTEMA DE CORES ANSI 256 / BBS 8-BIT
# ═══════════════════════════════════════════════════════════════════════
_c() {
    [ "$OPT_COLOR" = "0" ] && return
    printf '\033[%sm' "$1"
}

R='\033[0m'          # reset
BOLD='\033[1m'
DIM='\033[2m'
# Paleta RAFAELIA
C_PHI='\033[38;5;226m'    # amarelo ouro  — phi
C_SPI='\033[38;5;51m'     # ciano         — spiral
C_OMG='\033[38;5;201m'    # magenta       — omega
C_SIG='\033[38;5;93m'     # violeta       — sigma
C_OK='\033[38;5;46m'      # verde         — ok
C_ERR='\033[38;5;196m'    # vermelho      — erro
C_WRN='\033[38;5;208m'    # laranja       — aviso
C_INF='\033[38;5;39m'     # azul          — info
C_DIM='\033[38;5;240m'    # cinza         — dim

ARW01
echo 'B01 OK (linhas 1-65)'
