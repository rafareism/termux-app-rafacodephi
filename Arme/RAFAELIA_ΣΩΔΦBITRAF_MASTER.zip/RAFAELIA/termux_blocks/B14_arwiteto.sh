cat >> arwiteto.txt << 'ARW14'
        local bo="${obj}/_b${n}.o"
        if pipeline_compile_asm "$bs" "$bo"; then
            # Renomeia _start para bN_main se objcopy disponível
            command -v objcopy >/dev/null 2>&1 && \
                objcopy --redefine-sym _start=b${n}_main "$bo" "$bo" 2>/dev/null
            ok=$((ok+1))
        else
            fail=$((fail+1))
        fi
    done

    # Link shared lib
    if [ "$ok" -gt 0 ] && [ -n "$CC_BIN" ]; then
        log INF "Linkando librafaelia_gpu.so..."
        local objs; objs=$(ls "${obj}"/*.o 2>/dev/null | tr '\n' ' ')
        if $CC_BIN $CC_FLAGS -shared -fPIC $objs \
                -o "${obj}/librafaelia_gpu.so" -ldl 2>>"$ARW_LOG"; then
            log OK "librafaelia_gpu.so → $(ls -lh "${obj}/librafaelia_gpu.so" | awk '{print $5}')"
        else
            log WRN "Link shared falhou — objetos .o disponíveis em ${obj}/"
        fi
    fi

    section "RESUMO PIPELINE"
    kv "Módulos OK:"   "$ok"
    kv "Módulos FAIL:" "$fail"
    kv "Artefatos:"    "${obj}/"

    [ "$fail" -gt 0 ] && rollback_save "post_compile_with_errors"
    heartbeat
}

# ═══════════════════════════════════════════════════════════════════════
# [10] INSTALL MODULE
# ═══════════════════════════════════════════════════════════════════════
pkg_need() {
    local pkg="$1" cmd="${2:-$1}"
    command -v "$cmd" >/dev/null 2>&1 && return 0
    log WRN "Necessário: $pkg"
    return 1
}

pkg_install_termux() {
    [ "$IS_TERMUX" != "1" ] && return 1
    log INF "Instalando pacotes Termux necessários..."
    local pkgs="clang binutils"
    pkg install -y $pkgs >> "$ARW_LOG" 2>&1 && return 0
    return 1
}

install_deps() {
    section "DEPENDÊNCIAS"
    local missing=0

    pkg_need "clang"    "clang"   || missing=$((missing+1))
    pkg_need "binutils" "objcopy" || missing=$((missing+1))
    pkg_need "awk"      "awk"     || missing=$((missing+1))
    pkg_need "sed"      "sed"     || missing=$((missing+1))
    pkg_need "dd"       "dd"      || missing=$((missing+1))

    if [ "$missing" -gt 0 ] && [ "$IS_TERMUX" = "1" ]; then
        log WRN "$missing pacotes ausentes — tentando instalar..."
        pkg_install_termux && detect_compiler
    fi


ARW14
echo 'B14 OK (linhas 846-910)'
