cat >> arwiteto.txt << 'ARW16'

Watchdog:
  --timeout N  Timeout watchdog em segundos (padrão: 120)

Exemplos:
  ./arwiteto.sh                    # modo completo
  ./arwiteto.sh -m bench -s 42    # 42 amostras benchmark
  ./arwiteto.sh -m compile --dry  # dry run compilação
  ./arwiteto.sh -m detect         # apenas detecção

HELP
}

cli_parse() {
    while [ "$#" -gt 0 ]; do
        case "$1" in
            -m)          OPT_MODE="$2";         shift ;;
            -w)          OPT_WARMUP="$2";        shift ;;
            -s)          OPT_SAMPLES="$2";       shift ;;
            -i)          OPT_PREWARM_ITER="$2";  shift ;;
            -j)          OPT_JOBS="$2";          shift ;;
            --timeout)   OPT_WDOG_TIMEOUT="$2";  shift ;;
            --no-color)  OPT_COLOR=0 ;;
            --dry)       OPT_DRY=1 ;;
            -v)          OPT_VERBOSE=1 ;;
            -h|--help)   cli_help; exit 0 ;;
            *)           log WRN "Argumento desconhecido: $1" ;;
        esac
        shift
    done
}

# ═══════════════════════════════════════════════════════════════════════
# [13] CLEANUP / TRAP
# ═══════════════════════════════════════════════════════════════════════
cleanup() {
    local code=$?
    watchdog_stop
    [ "$code" -ne 0 ] && log WRN "Saída com código $code — verifique $ARW_LOG"
    printf '\n'
}
trap cleanup EXIT INT TERM

# ═══════════════════════════════════════════════════════════════════════
# [14] MAIN
# ═══════════════════════════════════════════════════════════════════════
main() {
    cli_parse "$@"

    mkdir -p "$ARW_HOME" "$ARW_CKPT" "$ARW_BUILD_DIR" "$ARW_BENCH_DIR"
    printf '[ARWITETO v%s START %s]\n' "$ARW_VER" \
        "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" > "$ARW_LOG"

    banner
    watchdog_start
    heartbeat

    detect_all

    case "$OPT_MODE" in
        detect)
            show_detect
            ;;
        bench)
            show_detect

ARW16
echo 'B16 OK (linhas 976-1040)'
