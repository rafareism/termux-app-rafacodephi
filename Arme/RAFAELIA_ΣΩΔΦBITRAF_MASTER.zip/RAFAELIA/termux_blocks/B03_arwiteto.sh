cat >> arwiteto.txt << 'ARW03'
}

spinner() {
    local pid="$1" msg="$2"
    local sp='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    local i=0
    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i+1) % 10 ))
        c=$(printf '%s' "$sp" | cut -c$((i+1)))
        printf "\r ${C_SPI}%s${R} %s..." "$c" "$msg"
        sleep 0.1
    done
    printf "\r                                        \r"
}

section() {
    printf "\n${C_SIG}${BOLD}┌─ %s %s${R}\n" "$1" \
        "$(printf "${C_DIM}$(_repeat '─' $((W-4-${#1})))${R}")"
}

kv() {
    printf " ${C_DIM}%-22s${R} ${C_BLK}%s${R}\n" "$1" "$2"
}

# ═══════════════════════════════════════════════════════════════════════
# [4] DETECT MODULE
# ═══════════════════════════════════════════════════════════════════════
ARCH=""
ABI=""
NCPU=1
HAS_NEON=0
HAS_CRC32=0
HAS_SVE=0
HAS_ASIMD=0
CPU_FREQ_MAX=0
CPU_FREQ_MIN=0
PAGE_SZ=4096
MEM_TOTAL_KB=0
OS_NAME=""
IS_TERMUX=0
IS_ANDROID=0
ANDROID_VER=""
CC_BIN=""
AS_BIN=""
CC_FLAGS=""

detect_arch() {
    local machine; machine=$(uname -m 2>/dev/null || echo "unknown")
    case "$machine" in
        aarch64|arm64)     ARCH="arm64";   ABI="arm64-v8a"   ;;
        armv7*|armv8*)     ARCH="arm32";   ABI="armeabi-v7a" ;;
        arm*)              ARCH="arm32";   ABI="armeabi-v7a" ;;
        x86_64|amd64)      ARCH="x86_64";  ABI="x86_64"      ;;
        i686|i386|x86)     ARCH="x86";     ABI="x86"         ;;
        *)                 ARCH="generic"; ABI="generic"      ;;
    esac

    # CPU count
    NCPU=$(grep -c '^processor' /proc/cpuinfo 2>/dev/null || echo 1)
    [ "$NCPU" -lt 1 ] && NCPU=1
    [ "$OPT_JOBS" = "0" ] && OPT_JOBS=$NCPU

    # Page size
    PAGE_SZ=$(getconf PAGE_SIZE 2>/dev/null || echo 4096)


ARW03
echo 'B03 OK (linhas 131-195)'
