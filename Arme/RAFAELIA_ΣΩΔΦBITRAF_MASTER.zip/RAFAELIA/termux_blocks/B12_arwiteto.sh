cat >> arwiteto.txt << 'ARW12'
    fi

    # HF-05: baremetal_nomalloc.c usa baremetal.h errado
    local bmc="${HOME}/rafaelia_full/core/baremetal_nomalloc.c"
    if [ -f "$bmc" ] && grep -q '"baremetal.h"' "$bmc"; then
        sed -i 's/"baremetal.h"/"baremetal_nomalloc.h"/' "$bmc" 2>/dev/null && \
            { log OK "HF-05: header corrigido em baremetal_nomalloc.c"; hf_count=$((hf_count+1)); }
    fi

    # HF-06: rollback condition impossível em rafaelia_glue.c
    local glue="${HOME}/rafaelia_full/core/rafaelia_glue.c"
    if [ -f "$glue" ] && grep -q '!sc || v->s\[0\] >= Q2PI' "$glue"; then
        sed -i 's/!sc || v->s\[0\] >= Q2PI/sc != v->crc_s/' "$glue" 2>/dev/null && \
            { log OK "HF-06: condição rollback corrigida em rafaelia_glue.c"; hf_count=$((hf_count+1)); }
    fi

    # HF-03: _SYM macro em rafaelia_gpu_cl.c
    local clc="${HOME}/rafaelia_full/gpu/rafaelia_gpu_cl.c"
    if [ -f "$clc" ] && grep -q '_SYM(n)' "$clc"; then
        # Substitui macro e todas as chamadas
        sed -i \
            's/#define _SYM(n) _D.n=(f_##n)dlsym(_D.lib,#n)/#define _SYM(f,sym) _D.f=(f_##f)dlsym(_D.lib,(sym))/' \
            "$clc" 2>/dev/null
        sed -i \
            's/_SYM(getPIDs)/_SYM(getPIDs,"clGetPlatformIDs")/
             s/_SYM(getDIDs)/_SYM(getDIDs,"clGetDeviceIDs")/
             s/_SYM(mkCtx)/_SYM(mkCtx,"clCreateContext")/
             s/_SYM(mkQ)/_SYM(mkQ,"clCreateCommandQueue")/
             s/_SYM(mkProg)/_SYM(mkProg,"clCreateProgramWithSource")/
             s/_SYM(build)/_SYM(build,"clBuildProgram")/
             s/_SYM(mkKern)/_SYM(mkKern,"clCreateKernel")/
             s/_SYM(mkBuf)/_SYM(mkBuf,"clCreateBuffer")/
             s/_SYM(setArg)/_SYM(setArg,"clSetKernelArg")/
             s/_SYM(wrBuf)/_SYM(wrBuf,"clEnqueueWriteBuffer")/
             s/_SYM(enqNDR)/_SYM(enqNDR,"clEnqueueNDRangeKernel")/
             s/_SYM(rdBuf)/_SYM(rdBuf,"clEnqueueReadBuffer")/
             s/_SYM(fin)/_SYM(fin,"clFinish")/' \
            "$clc" 2>/dev/null && \
            { log OK "HF-03: _SYM macro corrigida em rafaelia_gpu_cl.c"; hf_count=$((hf_count+1)); }
    fi

    log INF "Hotfixes aplicados: $hf_count"
    heartbeat
}

pipeline_compile_module() {
    local src="$1" out="$2" extra_flags="${3:-}"
    [ -z "$CC_BIN" ] && { log WRN "Sem compilador para $src"; return 1; }
    [ ! -f "$src" ]  && { log WRN "Fonte não encontrado: $src"; return 1; }

    local inc_dirs="-I${HOME}/rafaelia_full/gpu -I${HOME}/rafaelia_full/core"

    if "$CC_BIN" $CC_FLAGS $inc_dirs $extra_flags -c "$src" -o "$out" 2>>"$ARW_LOG"; then
        log OK "  Compilado: $(basename "$src")"
        MODULES_OK="${MODULES_OK} $src"
        return 0
    else
        log ERR "  FALHA: $(basename "$src")"
        MODULES_FAIL="${MODULES_FAIL} $src"
        return 1
    fi
}

pipeline_compile_asm() {
    local src="$1" out="$2"

ARW12
echo 'B12 OK (linhas 716-780)'
