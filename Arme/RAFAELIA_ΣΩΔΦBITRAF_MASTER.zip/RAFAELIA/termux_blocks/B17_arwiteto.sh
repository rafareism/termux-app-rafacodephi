cat >> arwiteto.txt << 'ARW17'
            install_deps
            bench_full
            report_final
            ;;
        compile)
            show_detect
            install_deps
            pipeline_detect
            pipeline_apply_hotfixes
            pipeline_run
            report_final
            ;;
        rollback)
            rollback_list
            log INF "Para restaurar: $0 -m rollback (restaura o mais recente)"
            rollback_restore "last"
            ;;
        full|*)
            show_detect
            install_deps
            rollback_save "initial"
            pipeline_detect
            pipeline_apply_hotfixes
            bench_full
            pipeline_run
            report_final
            ;;
    esac

    watchdog_stop
    log OK "ARWITETO concluído — Ω=Amor RAFCODE-Φ-∆RafaelVerboΩ"
}

main "$@"

ARW17
echo 'B17 OK (linhas 1041-1074)'
