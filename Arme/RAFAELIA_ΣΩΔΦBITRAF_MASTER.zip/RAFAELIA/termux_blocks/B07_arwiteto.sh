cat >> arwiteto.txt << 'ARW07'
soc_read_freq() {
    # Retorna frequência atual do cpu0 em kHz
    cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq 2>/dev/null || \
    cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_cur_freq 2>/dev/null || \
    echo "$CPU_FREQ_MAX"
}

soc_read_temp() {
    # Retorna temperatura em milli-Celsius ou 0
    local t=0
    for z in /sys/class/thermal/thermal_zone*/temp; do
        [ -f "$z" ] && t=$(cat "$z" 2>/dev/null) && break
    done
    echo "$t"
}

soc_snapshot() {
    # Retorna: freq_khz temp_mc timestamp
    printf '%s %s %s' "$(soc_read_freq)" "$(soc_read_temp)" "$(date +%s%N 2>/dev/null || date +%s)"
}

soc_show() {
    local freq temp
    freq=$(soc_read_freq)
    temp=$(soc_read_temp)
    kv "CPU freq atual:"  "$(echo "$freq" | awk '{printf "%.0f MHz", $1/1000}')"
    kv "Temperatura:"     "$(echo "$temp" | awk '{printf "%.1f °C", $1/1000}')"
}

# ═══════════════════════════════════════════════════════════════════════
# [8] BENCHMARK ENGINE
# ═══════════════════════════════════════════════════════════════════════

# Timing em nanosegundos — usa /proc/uptime se date +%N não disponível
_now_ns() {
    local ns
    ns=$(date +%s%N 2>/dev/null)
    if [ "$ns" = "%s%N" ] || [ -z "$ns" ]; then
        # Fallback: /proc/uptime (centisegundos → ns)
        ns=$(awk '{printf "%d", $1*1000000000}' /proc/uptime 2>/dev/null || echo 0)
    fi
    echo "$ns"
}

# Kernel benchmark: CRC32 software em shell puro (determinístico)
_bench_kernel_shell() {
    local iters="${1:-100000}"
    local acc=0 i=0 v
    while [ "$i" -lt "$iters" ]; do
        v=$(( (acc ^ i) * 0x9e3779b9 ))
        acc=$(( v & 0x7FFFFFFF ))
        i=$(( i + 1 ))
    done
    echo "$acc"
}

# Benchmark dd (memória e I/O)
_bench_dd() {
    local bs="${1:-1M}" count="${2:-32}"
    dd if=/dev/zero of=/dev/null bs="$bs" count="$count" 2>&1 | \
        awk '/copied/{print $NF" "$( NF-1)}'
}

# Benchmark compilador (se disponível)
_bench_compile() {

ARW07
echo 'B07 OK (linhas 391-455)'
