cat >> arwiteto.txt << 'ARW09'
        if(n%2==1) median=a[int(n/2)+1]
        else       median=(a[n/2]+a[n/2+1])/2
        # Moda (bucket 5% de range)
        bkt=int((max-min)/10)+1
        for(i=1;i<=n;i++){b=int((a[i]-min)/bkt); cnt[b]++}
        mmax=0; mbin=0
        for(b in cnt){if(cnt[b]>mmax){mmax=cnt[b];mbin=b}}
        modal=min+mbin*bkt+bkt/2
        # CV e classificação
        cv=(mean>0)?std/mean:0
        if(cv<0.03)      dist="HOMOGENEO"
        else if(cv<0.10) dist="ESTAVEL"
        else if(cv<0.25) dist="VARIAVEL"
        else             dist="CAOTICO"
        # Skewness simples
        sk=(mean-median)
        if(sk>0) skew="ASSIMETRICO+"
        else if(sk<0) skew="ASSIMETRICO-"
        else skew="SIMETRICO"
        printf "n=%d min=%d max=%d mean=%.1f median=%.1f std=%.1f cv=%.4f dist=%s skew=%s modal=%.1f\n",
            n, min, max, mean, median, std, cv, dist, skew, modal
    }' "$file"
}

# Benchmark completo com relatório
bench_full() {
    mkdir -p "$ARW_BENCH_DIR"
    local raw="${ARW_BENCH_DIR}/raw_samples.txt"
    local soc_pre soc_post
    local s i pct

    section "BENCHMARK INDUSTRIAL"
    log INF "Amostras: $OPT_SAMPLES | Warmup: ${OPT_WARMUP}s | Kernel: shell-CRC Q16.16"

    # SOC inicial
    log INF "SOC baseline inicial:"
    soc_pre=$(soc_snapshot)
    soc_show

    # Pré-aquecimento
    bench_warmup
    heartbeat

    # SOC pós-warmup
    log INF "SOC pós-warmup:"
    soc_show

    rollback_save "bench_start"

    # Coleta amostras
    log INF "Coletando $OPT_SAMPLES amostras..."
    rm -f "$raw"
    i=1
    while [ "$i" -le "$OPT_SAMPLES" ]; do
        s=$(bench_sample)
        echo "$s" >> "$raw"
        pct=$(( i * 100 / OPT_SAMPLES ))
        progress_bar "$pct" "amostra $i/$OPT_SAMPLES → ${s}µs  "
        heartbeat
        i=$(( i + 1 ))
    done
    printf '\n'

    # SOC pós-benchmark
    soc_post=$(soc_snapshot)

ARW09
echo 'B09 OK (linhas 521-585)'
