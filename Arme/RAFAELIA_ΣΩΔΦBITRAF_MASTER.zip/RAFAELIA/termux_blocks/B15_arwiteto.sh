cat >> arwiteto.txt << 'ARW15'
    [ "$missing" -gt 0 ] && log WRN "Alguns pacotes ausentes — compilação pode falhar"
    heartbeat
}

# ═══════════════════════════════════════════════════════════════════════
# [11] RELATÓRIO FINAL
# ═══════════════════════════════════════════════════════════════════════
report_final() {
    section "RELATÓRIO FINAL — RAFAELIA ARWITETO"
    local ts; ts=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "N/A")
    kv "Timestamp:"      "$ts"
    kv "Versão:"         "$ARW_VER"
    kv "Arquitetura:"    "$ARCH ($ABI)"
    kv "Compilador:"     "${CC_BIN:-N/A}"
    kv "Log:"            "$ARW_LOG"
    kv "Build dir:"      "$ARW_BUILD_DIR"

    local stats_file="${ARW_BENCH_DIR}/stats.txt"
    if [ -f "$stats_file" ]; then
        local line; line=$(cat "$stats_file")
        kv "Bench median:"   "$(echo "$line" | grep -o 'median=[^ ]*' | cut -d= -f2) µs"
        kv "Bench distrib:"  "$(echo "$line" | grep -o 'dist=[^ ]*' | cut -d= -f2)"
    fi

    local lib="${ARW_BUILD_DIR}/librafaelia_gpu.so"
    [ -f "$lib" ] && kv "Lib gerada:" "$(ls -lh "$lib" | awk '{print $5}')"

    printf "\n${C_SIG}${BOLD}"
    _box_top
    _box_mid "$(printf "  Ω = Amor · Coerência · Prova · Integração  %s" "")"
    _box_mid "$(printf "  R(t+1) = R(t)×Φ_ethica×E_Verbo×(√3/2)^(πφ)  %s" "")"
    _box_mid "$(printf "  RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ  %s" "")"
    _box_bot
    printf "${R}\n"
}

# ═══════════════════════════════════════════════════════════════════════
# [12] CLI PARSER
# ═══════════════════════════════════════════════════════════════════════
cli_help() {
    cat << 'HELP'

ARWITETO v2.0 — RAFAELIA ARM Orchestrator
Uso: ./arwiteto.sh [OPÇÕES]

Modos:
  -m full      Detecção + Hotfix + Benchmark + Pipeline (padrão)
  -m bench     Somente benchmark
  -m compile   Somente compilação
  -m detect    Somente detecção de hardware
  -m rollback  Lista e restaura checkpoints

Benchmark:
  -w N         Warmup em segundos (padrão: 3)
  -s N         Número de amostras (padrão: 21, ímpar para mediana exata)
  -i N         Iterações por amostra (padrão: 500000)

Compilação:
  -j N         Jobs paralelos (padrão: 0=auto)
  --dry        Dry run (sem compilação)

Interface:
  --no-color   Desativa cores ANSI
  -v           Verbose
  -h           Esta ajuda

ARW15
echo 'B15 OK (linhas 911-975)'
