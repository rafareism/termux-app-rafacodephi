cat >> arwiteto.txt << 'ARW13'
    local as_flags="-march=armv7-a -mfpu=neon-vfpv4 -mfloat-abi=softfp"
    [ "$ARCH" = "arm64" ] && as_flags="-march=armv8-a"
    [ "$ARCH" = "x86_64" ] && as_flags=""

    local assembler="${AS_BIN:-as}"

    if "$assembler" $as_flags "$src" -o "$out" 2>>"$ARW_LOG"; then
        log OK "  Montado: $(basename "$src")"
        return 0
    else
        log ERR "  ASM FALHA: $(basename "$src") — tentando clang"
        if [ -n "$CC_BIN" ] && "$CC_BIN" $CC_FLAGS -c "$src" -o "$out" 2>>"$ARW_LOG"; then
            log OK "  Montado via clang: $(basename "$src")"
            return 0
        fi
        return 1
    fi
}

pipeline_run() {
    [ "$OPT_DRY" = "1" ] && { log WRN "DRY RUN — compilação ignorada"; return 0; }
    section "PIPELINE DE COMPILAÇÃO"

    mkdir -p "$ARW_BUILD_DIR"
    rollback_save "pre_compile"

    local base="${HOME}/rafaelia_full"
    local obj="$ARW_BUILD_DIR"
    local ok=0 fail=0

    # Módulos C em ordem de dependência
    local c_mods="gpu/rafaelia_gpu_prim.c
                  gpu/rafaelia_gpu_cl.c
                  gpu/rafaelia_gpu_orch.c
                  bridge/rafaelia_bridge_orch_gpu.c
                  core/bitstack.c"

    for mod in $c_mods; do
        local src="${base}/${mod}"
        local oname; oname=$(basename "$src" .c).o
        local out="${obj}/${oname}"
        heartbeat
        if pipeline_compile_module "$src" "$out"; then
            ok=$((ok+1))
        else
            fail=$((fail+1))
        fi
    done

    # NEON ASM
    local asm_src="${base}/gpu/rafaelia_neon_k.S"
    if [ -f "$asm_src" ]; then
        heartbeat
        if pipeline_compile_asm "$asm_src" "${obj}/rafaelia_neon_k.o"; then
            ok=$((ok+1))
        else
            fail=$((fail+1))
        fi
    fi

    # b1-b8 ASM (se existirem)
    for n in 1 2 3 4 5 6 7 8; do
        local bs="${base}/asm/rafaelia_b${n}.S"
        [ -f "$bs" ] || continue
        heartbeat

ARW13
echo 'B13 OK (linhas 781-845)'
