#!/bin/sh
chmod +x arwiteto.txt
mv arwiteto.txt arwiteto.sh
echo "=========================================="
echo " ARWITETO PRONTO"
echo "=========================================="
echo " ./arwiteto.sh              # modo completo"
echo " ./arwiteto.sh -m detect    # so deteccao"
echo " ./arwiteto.sh -m bench     # so benchmark"
echo " ./arwiteto.sh -m compile   # so compilacao"
echo " ./arwiteto.sh -h           # ajuda"
echo "=========================================="
